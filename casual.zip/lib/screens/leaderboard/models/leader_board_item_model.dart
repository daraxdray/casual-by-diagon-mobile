class LeaderBoardItemModel {
  final int score;
  final int rank;
  LeaderBoardItemModel({required this.score,required this.rank, });

}
