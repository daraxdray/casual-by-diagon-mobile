class Tournament {
  int reward;
  String bgImage;
  String gameImage;
  int endsIn;
  String title;

  Tournament({required this.reward,required this.bgImage, required this.gameImage, required this.endsIn, required this.title});

}